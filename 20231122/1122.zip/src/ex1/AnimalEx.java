package ex1;

public class AnimalEx {
	public static void main(String[] args) {
		
		//Animal a = new Dog();
		
		//if ������ ����
		//if (num == 1) {
			//a = new Dog();
		}
		
		//a.act();
	}
}
