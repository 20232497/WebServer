package ex4;

public class Driver {
	/*void drive(Vehicle vehicle) {
		vehicle.run();
	}*/
}
