package ex4;

public interface Vehicle {
	void run();
}	
