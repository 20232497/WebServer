package ex6;

public interface Animal {
	
	void action(String Animal, String Act, String Sound);
}
