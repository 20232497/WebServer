package ex3;

public interface InterfaceA {
	public void methodA();
}
