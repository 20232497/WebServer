package ex3;

public interface InterfaceB {
	public void methodB();
}
