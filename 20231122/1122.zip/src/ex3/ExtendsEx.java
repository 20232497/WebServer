package ex3;

public class ExtendsEx {
	public static void main(String[] args) {
		
		InterfaceCImpl cimpl = new InterfaceCImpl();
		
		InterfaceA ia = (InterfaceA) cimpl;
		ia.methodA();
		//ia.methodB();
		System.out.println();
		
		InterfaceB ib = (InterfaceB) cimpl;
		//ib.methodA();
		ib.methodB();
		System.out.println();
		
		InterfaceC ic = (InterfaceC) cimpl;
		ic.methodA();
		ic.methodB();
		ic.methodC();
	}
}
