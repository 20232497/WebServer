package ex3;

public class InterfaceCImpl implements InterfaceC{
	public void methodA() {
		System.out.println("InterfaceImpl-methodA() ����");
	}
	public void methodB() {
		System.out.println("InterfaceImpl-methodB() ����");
	}
	public void methodC() {
		System.out.println("InterfaceImpl-methodC() ����");
	}
}
