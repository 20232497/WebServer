package ex5;

import java.util.Scanner;

public class AnimalEx {
	public static void main(String[] args) {
		
		System.out.println("�˾ƺ� ������ �����Ͻÿ�.");
		System.out.println("1. �� " + "2. ������ " + "3. �ξ��� " + "4. ȣ���� ");
		System.out.print("select : " );
		
		Scanner s = new Scanner(System.in);
		int i = s.nextInt();
		
		if(i == 1) {
			Dog dog = new Dog();
			dog.Act();
			dog.Sound();
		}
		else if (i == 2) {
			Cat cat = new Cat();
			cat.Act();
			cat.Sound();
		}
		else if (i == 3) {
			Owl owl = new Owl();
			owl.Act();
			owl.Sound();
		}
		else {
			Tiger tiger = new Tiger();
			tiger.Act();
			tiger.Sound();
		}
	}
}
