package ex5;

public class Animal {
	
	public void Act() {
		
	}
	public void Sound() {
		
	}
}
