package ex2;

public interface RemoteControl {
	
	void turnOn();
	void turnOff();
}
