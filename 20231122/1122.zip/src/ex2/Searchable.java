package ex2;

public interface Searchable {

	void search(String url);
}
